require('dotenv').config();

const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { MongoClient, ServerApiVersion } = require('mongodb');

const app = express();
const port = process.env.PORT || 5000;

// middleware
app.use(cors());
app.use(express.json());
//
// MongoDB Atlas Conntection URL
const uri = `mongodb+srv://dextermiranda441:ZTKQ94nSwtW81tcW@cluster0.swfod.mongodb.net/ratan`;
// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true
  }
});

// Routes import
const productRoutes = require('./routes/products');
const reviewRoutes = require('./routes/reviews');
const cartRoutes = require('./routes/carts');
const favouriteRoutes = require('./routes/favourites');
const orderRoutes = require('./routes/orders');
const adminRoutes = require('./routes/admin');
const paymentRoutes = require('./routes/payments');
const userRoutes = require('./routes/users');
const paypal = require('paypal-rest-sdk');
// Configure PayPal SDK
paypal.configure({
  mode: 'sandbox', // Use 'live' for production
  client_id:
    'AaKrK9r6rk6KZX3McNtTA0UWsYVAZAJQqSvc5I8cZFM5PpbxE1wDoZ3_CHq-NOxh_OIrUq9IwfzwneP9',
  client_secret:
    'EAUNgaQfc5NMFS31x02M6ysk23W5yeK30WCpS5rPE8fn9m4l51tbbbmgvZFc6ar9Sa9VRJn7gqNvXpUP'
});

async function run() {
  try {
    // Connect the client to the server	(optional starting in v4.7)
    await client.connect();

    // Database
    const db = client.db('handihubDB');
    // const oldDb = client.db('urbanAuraDb');
    // const newDb = client.db('handihubDB');

    // // Get a list of all collections in the old database
    // const collections = await oldDb.listCollections().toArray();

    // // Loop through the collections and copy them to the new database
    // for (const collection of collections) {
    //   const oldCollection = oldDb.collection(collection.name);
    //   const newCollection = newDb.collection(collection.name);

    //   // Copy documents from old collection to new collection
    //   const documents = await oldCollection.find({}).toArray();
    //   if (documents.length > 0) {
    //     await newCollection.insertMany(documents);
    //   }
    // }

    // console.log(
    //   `Successfully renamed database from ${oldDbName} to ${newDbName}`
    // );

    // Database Collections
    const productsCollection = db.collection('products');
    const cartsCollection = db.collection('carts');
    const favouritesCollection = db.collection('favourites');
    const ordersCollection = db.collection('orders');
    const reviewsCollection = db.collection('reviews');
    const membershipCollection = db.collection('membership');
    // Routes

    app.use('/api/products', productRoutes(productsCollection));

    app.use('/api/reviews', reviewRoutes(reviewsCollection));
    app.use('/api/carts', cartRoutes(cartsCollection));
    app.use('/api/favourites', favouriteRoutes(favouritesCollection));
    app.use('/api/orders', orderRoutes(ordersCollection, cartsCollection));
    app.use('/api/admin', adminRoutes(ordersCollection, productsCollection));
    app.use(
      '/api/users',
      userRoutes(membershipCollection, ordersCollection, cartsCollection)
    );
    app.use('/api/payments', paymentRoutes());

    app.post('/webhook/paymongo', (req, res) => {
      // The event data will be in req.body
      const event = req.body;

      // Process the event based on its type
      if (event.type === 'source.chargeable') {
        // Handle the event when a source becomes chargeable
        console.log('Source is chargeable:', event.data);
      } else if (event.type === 'payment.paid') {
        // Handle successful payment event
        console.log('Payment is successful:', event.data);
      }

      // Respond with a 200 status code to acknowledge receipt of the event
      res.status(200).send({ received: true });
    });

    // JWT Token API
    app.post('/api/jwt', (req, res) => {
      const user = req.body;

      console.log({ user });
      const token = jwt.sign(user, 'secret', {
        expiresIn: '30d'
      });
      res.send({ token });
    });

    // Send a ping to confirm a successful connection
    await client.db('admin').command({ ping: 1 });
    console.log(
      'Pinged your deployment. You successfully connected to MongoDB!'
    );
  } finally {
    // Ensures that the client will close when you finish/error
    // await client.close();
  }
}
run().catch(console.dir);

app.get('/', (req, res) => {
  res.send(`server is running`);
});

app.listen(port, () => {
  console.log(` server is running on port: ${port}`);
});

// Create PayPal order
app.post('/create-order', (req, res) => {
  console.log('dex');
  const create_payment_json = {
    intent: 'sale',
    payer: {
      payment_method: 'paypal'
    },
    transactions: [
      {
        amount: {
          currency: 'PHP',
          total: '500.00'
        },
        description: 'Payment description'
      }
    ],
    redirect_urls: {
      return_url: 'http://localhost:5000/success',
      cancel_url: 'http://localhost:5000/cancel'
    }
  };

  paypal.payment.create(create_payment_json, (error, payment) => {
    if (error) {
      res.status(500).send(error);
    } else {
      res.json({ id: payment.id });
    }
  });
});

// Capture PayPal order
app.post('/capture-order', (req, res) => {
  const { orderID } = req.body;

  paypal.payment.execute(orderID, {}, (error, payment) => {
    if (error) {
      res.status(500).send(error);
    } else {
      res.json(payment);
    }
  });
});
