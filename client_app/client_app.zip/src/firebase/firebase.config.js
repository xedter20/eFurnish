import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCmgWeuOcredGzeg-KR58Po6GeNaokRRo4",
  authDomain: "ratan-eccomerce.firebaseapp.com",
  projectId: "ratan-eccomerce",
  storageBucket: "ratan-eccomerce.appspot.com",
  messagingSenderId: "423849454417",
  appId: "1:423849454417:web:7e5c1f9a69fa20ea738170",
  measurementId: "G-MELXH9Z5F6",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export { app, db, auth, provider };
