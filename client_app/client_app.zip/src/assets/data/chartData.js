export const bardata = [
  {
    name: "Sep",
    Sales: 2290,
  },
  {
    name: "October",
    Sales: 5000,
  },
];

export const pieData = [
  { name: "Chair", value: 800 },
  { name: "Bed", value: 450 },
  { name: "Lamp", value: 243 },
  { name: "Table", value: 362 },
];

export const pieColors = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];
