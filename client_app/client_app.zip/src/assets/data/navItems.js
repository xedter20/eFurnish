// Navigation Menu Links
export const navItems = [
  { link: "/", text: "Home", isAdmin: false },
  { link: "/shop", text: "Shop", isAdmin: false },
  { link: "/about", text: "About", isAdmin: false },
  {
    link: "/video-tutorials",
    text: "Video Tutorials / Membership",
    isAdmin: false,
  },
  // { link: "/membership", text: "Membership", isAdmin: false },
  { link: "/contact", text: "Contact", isAdmin: false },
];
