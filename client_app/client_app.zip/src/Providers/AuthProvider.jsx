import { createContext, useEffect, useState } from "react";
import {
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  deleteUser,
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  sendEmailVerification
} from "firebase/auth";
import { app } from "../firebase/firebase.config";

import { getFirestore, doc, setDoc } from "firebase/firestore";


const db = getFirestore();

import axios from "axios";

export const AuthContext = createContext(null);

import toast from "react-hot-toast";

const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Sign-up new user using Email and Password
  const createUser = async (email, password) => {
    setLoading(true);
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);

    // console.log({ userCredential })


    // Save user role in Firestore
    // const user = userCredential.user;
    // await setDoc(doc(db, "users", user.uid), {
    //   email: user.email,
    //   role: role, // 'admin' or 'user'
    // });
    await sendEmailVerification(userCredential.user)
    toast.success("Account created successfully.You need to verify your email first. Please check your inbox");
    return userCredential;
  };

  // Email and Password Login
  const signIn = async (email, password) => {
    setLoading(true);



    const userCredential = await signInWithEmailAndPassword(
      auth,
      email,
      password
    );

    const user = userCredential;

    return user;

  };

  //  Google Login
  const googleSignIn = () => {
    setLoading(true);
    return signInWithPopup(auth, googleProvider);
  };

  // Update user profile name
  const updateUserProfile = (name, photo) => {
    setLoading(true);
    if (name && photo) {
      return updateProfile(auth.currentUser, {
        displayName: name,
        photoURL: photo,
      });
    } else {
      return updateProfile(auth.currentUser, {
        displayName: name,
      });
    }
  };

  // Log out
  const logOut = () => {
    setLoading(true);
    return signOut(auth);
  };

  // Delete User's Account
  const deleteAccount = () => {
    setLoading(true);
    return deleteUser(auth.currentUser);
  };

  // authentication observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setLoading(true);

      if (currentUser) {
        try {
          const res = await axios.post(`/jwt`, {
            email: currentUser.email,
          });
          localStorage.setItem("access-token", res.data.token);
        } catch (error) {
          console.error("Error fetching token:", error);
        }
      } else {
        localStorage.removeItem("access-token");
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const authInfo = {
    loading,
    user,
    signIn,
    googleSignIn,
    createUser,
    updateUserProfile,
    logOut,
    setLoading,
    setUser,
    deleteAccount,
  };
  return (
    <AuthContext.Provider
      value={authInfo}


    >{children}</AuthContext.Provider>
  );
};

export default AuthProvider;
