import { useState, useRef, useEffect } from 'react';
import { useLocation } from "react-router-dom";

import InputText from '../../../components/Input/InputText';
import { Formik, useField, useFormik, Form } from 'formik';
import * as Yup from 'yup';

import PageBanner from "../../../components/PageBanner/PageBanner";
import img1 from "../../../assets/images/about/about-1.jpg";
import img2 from "../../../assets/images/about/about-2.jpg";
import img3 from "../../../assets/images/about/about-3.jpg";

import Membership from "../../../Pages/SitePages/About/Membership"
import '@fortawesome/fontawesome-free/css/all.min.css'; // Ensure Font Awesome is imported


import axios from "axios";
import useAuth from "../../../hooks/useAuth";
const VideoPlayer = ({ videoId, videoSrc, onComplete }) => {
  const videoRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleEnd = () => {
    onComplete();
    setIsPlaying(false);
  };

  return (
    <div className="video-player">
      {/* aa */}
      <h2 className="text-xl font-semibold mb-2">{videoId}</h2>
      <video
        ref={videoRef}
        src={videoSrc}
        onEnded={handleEnd}
        className="w-full h-90 rounded-lg border-2 border-gray-300" // Adjusted height here
      />
      <div className="flex justify-between mt-2">
        <button onClick={handlePlayPause} className="py-2 px-4 bg-blue-500 text-white rounded transition duration-200 hover:bg-blue-600">
          {isPlaying ? 'Pause' : 'Play'}
        </button>
        <input
          type="range"
          min="0"
          max="100"
          value={videoRef.current ? (videoRef.current.currentTime / videoRef.current.duration) * 100 : 0}
          onChange={(e) => {
            const newTime = (e.target.value / 100) * videoRef.current.duration;
            videoRef.current.currentTime = newTime;
          }}
          className="w-full mx-4"
        />
        {/* <button
          onClick={() => (videoRef.current.currentTime = videoRef.current.duration)} // This allows the user to skip to the end but not fast-forward.
          className="py-2 px-4 bg-gray-300 text-gray-600 rounded transition duration-200 hover:bg-gray-400"
        >
          End
        </button> */}
      </div>
    </div>
  );
};
const About = () => {
  const { user } = useAuth();
  const { pathname } = useLocation();
  const [loading, setLoading] = useState(false);

  const formikConfig = {
    initialValues: {
      email: '',
      password: ''
    },
    validationSchema: Yup.object({
      email: Yup.string().required('Required field'),
      password: Yup.string()
        .min(8, 'Minimun of 8 character(s)')
        .required('Required field')
    }),
    onSubmit: async (
      values,
      { setSubmitting, setFieldValue, setErrorMessage, setErrors }
    ) => {

    }
  };

  const [activeTab, setActiveTab] = useState(0);
  const [videoCompleted, setVideoCompleted] = useState([false, false, false]);

  const handleVideoComplete = (index) => {
    const updatedCompleted = [...videoCompleted];
    updatedCompleted[index] = true;
    setVideoCompleted(updatedCompleted);
    if (index < videoCompleted.length - 1) {
      setActiveTab(index + 1); // Move to next tab if the current one is completed
    }
  };

  const [activeMembership, setActiveMembership] = useState([]);

  const listActiveMembership = async () => {
    let res = await axios({
      method: 'POST',
      url: `users/getMembership`,
      data: {
        email: user.email
      }
    }).then(async (res) => {
      let data = res.data.data;



      setActiveMembership(data)

    });




  };
  useEffect(() => {
    listActiveMembership();
  }, []);



  let memId = activeMembership?._id
  return (
    <section>
      {/* <PageBanner pathname={pathname} /> */}
      <div className="container mx-auto p-6 bg-gray-50 rounded-lg shadow-md">
        <h1 className="text-2xl font-semibold mb-6 text-center"></h1>
        <div className="flex space-x-4 mb-4">
          {['Tutorial 1', 'Tutorial 2', 'Membership'].map((video, index) => (
            <button
              key={index}
              onClick={() => setActiveTab(index)}
              className={`py-2 px-4 rounded-md text-white transition duration-200 ${memId || index <= activeTab ? 'bg-blue-500 hover:bg-blue-600' : 'bg-gray-300 cursor-not-allowed'
                }`}
              disabled={!memId && index > activeTab}
            >

              {video}
              {videoCompleted[index] && <i className="ml-4 fas fa-check text-green"></i>} {/* Check icon */}
            </button>
          ))}
        </div>

        <div className="video-container mb-6 p-4 bg-white rounded-lg shadow">
          {activeTab === 0 && (
            <VideoPlayer
              videoId="How to make rattan basket"

              videoSrc="https://firebasestorage.googleapis.com/v0/b/ratan-eccomerce.appspot.com/o/How_to_make_Rattan_Basket_tutorial.mp4?alt=media&token=aa6f7260-3e69-49f9-b275-8264c2bc58d2" // URL for Video 1
              onComplete={() => handleVideoComplete(0)}
            />
          )}
          {activeTab === 1 && (
            <VideoPlayer
              videoId="Weaving of rattan"
              videoSrc="https://firebasestorage.googleapis.com/v0/b/ratan-eccomerce.appspot.com/o/basic%20tutorial%20of%20weaving%20rattan.mp4?alt=media&token=cd62d072-57e7-4c51-b9e6-ac85a48bc7b9" // URL for Video 2
              onComplete={() => handleVideoComplete(1)}
            />
          )}
          {activeTab === 2 && (
            <Membership />
          )}
        </div>
      </div>
    </section>
  );
};

export default About;
