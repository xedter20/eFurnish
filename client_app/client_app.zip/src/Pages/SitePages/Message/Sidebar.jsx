// src/components/Sidebar.js
import React, { useState } from "react";
import { FaUserCircle } from "react-icons/fa";
import useAuth from "../../../hooks/useAuth";

const Sidebar = ({ users, onUserSelect, selectedUserId, unreadCounts }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const { user } = useAuth();

  let filteredUsers = users.filter(u => u.email !== user?.email)
    .filter((user) => {
      return user.displayName && user.displayName.toLowerCase().includes(searchQuery.toLowerCase()) || user.email.toLowerCase().includes(searchQuery.toLowerCase());
    })
  // .sort((a, b) => {
  //   const nameA = a.displayName?.toLowerCase() || "";
  //   const nameB = b.displayName?.toLowerCase() || "";
  //   return nameA.localeCompare(nameB); // Sort by displayName
  // });;

  return (
    <div className="w-80 h-full bg-gray-800 text-white overflow-y-auto">
      <h2 className="text-2xl p-4">Users</h2>
      <div className="p-4">
        <input
          type="text"
          placeholder="Search users..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full p-2 rounded bg-gray-700 text-white"
        />
      </div>
      <ul className="space-y-2">
        {filteredUsers.map((user) => (
          <li
            key={user.uid}
            onClick={() => onUserSelect(user.uid)}
            className={`flex items-center p-4 cursor-pointer space-x-3 ${selectedUserId === user.uid ? "bg-blue-600" : "hover:bg-gray-700"}`}
          >
            <FaUserCircle className="text-2xl" />
            <span>{user.displayName || user.email}</span>
            {/* {unreadCounts[user.uid] > 0 && (
              <span className="ml-auto text-red-500">{unreadCounts[user.uid]}</span>
            )} */}
          </li>
        ))}
        {filteredUsers.length === 0 && (
          <li className="p-4 text-gray-400">No users found</li>
        )}
      </ul>
    </div>
  );
};

export default Sidebar;
