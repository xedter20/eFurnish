// src/components/App.js
import React, { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import ChatInterface from "./ChatInterface";
import axios from "axios";
import { getFirestore, collection, query, where, onSnapshot } from "firebase/firestore";
import { db } from "../../../firebase/firebase.config";
import useAuth from "../../../hooks/useAuth";
import useAdmin from "../../../hooks/useAdmin";

const App = () => {
  const [selectedUserId, setSelectedUserId] = useState(null);
  const { isAdmin, adminLoading } = useAdmin();
  const [isLoaded, setIsLoaded] = useState(false);
  const { user } = useAuth();
  const currentUserId = user?.uid;
  const [users, setUsers] = useState([]);
  const [unreadCounts, setUnreadCounts] = useState({});
  const [latestMessageTimestamps, setLatestMessageTimestamps] = useState({}); // Track latest timestamps

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('/users/getAllUsers');
        const usersData = response.data;

        const filteredUsers = isAdmin
          ? usersData
          : usersData.filter((u) => u.email === 'admin_handihub@gmail.com');

        setUsers(filteredUsers);
        setIsLoaded(true);

        // Set up Firestore listener for unread message counts and latest timestamps
        setupUnreadCountsListener(filteredUsers);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };
    console.log({ currentUserId })
    const setupUnreadCountsListener = (users) => {
      const counts = {};
      const timestamps = {}; // Object to track latest message timestamps



      users.forEach(user => {
        // console.log(`${user.uid}++${currentUserId}`)
        const messagesQuery = query(
          collection(db, "chats", `${user.uid}++${currentUserId}`, "messages"),
          where("receiverId", "==", currentUserId)
        );

        // Set up a real-time listener for each user's messages
        onSnapshot(messagesQuery, (snapshot) => {
          counts[user.uid] = snapshot.size; // Update unread count

          // Update latest message timestamp
          snapshot.forEach(doc => {

            // console.log({ doc })
            const messageData = doc.data();
            if (messageData.timestamp) {
              timestamps[user.uid] = timestamps[user.uid] || messageData.timestamp;
              if (messageData.timestamp.toMillis() > timestamps[user.uid].toMillis()) {
                timestamps[user.uid] = messageData.timestamp;
              }
            }
          });

          setUnreadCounts(prevCounts => ({
            ...prevCounts,
            [user.uid]: counts[user.uid],
          }));

          setLatestMessageTimestamps(prevTimestamps => ({
            ...prevTimestamps,
            ...timestamps,
          }));
        });
      });
    };

    fetchUsers();
  }, [isAdmin, adminLoading, currentUserId]);

  const selectedUser = users.find(user => user.uid === selectedUserId);
  const selectedUserName = selectedUser ? selectedUser.displayName || selectedUser.email : "";

  // Sort users based on the latest message timestamps

  // console.log({ latestMessageTimestamps })
  const sortedUsers = users.sort((a, b) => {
    const nameA = a.displayName?.toLowerCase() || "";
    const nameB = b.displayName?.toLowerCase() || "";
    return nameA.localeCompare(nameB); // Sort by displayName
  });;
  // sort((a, b) => {
  //   const aTimestamp = latestMessageTimestamps[a.uid] || 0; // Default to 0 if no timestamp
  //   const bTimestamp = latestMessageTimestamps[b.uid] || 0; // Default to 0 if no timestamp
  //   return bTimestamp - aTimestamp; // Sort in descending order
  // });

  return isLoaded && (
    <div className="flex h-screen">
      <Sidebar
        users={sortedUsers} // Pass sorted users to Sidebar
        onUserSelect={setSelectedUserId}
        selectedUserId={selectedUserId}
        unreadCounts={unreadCounts}
      />
      <ChatInterface
        selectedUserId={selectedUserId}
        currentUserId={currentUserId}
        selectedUserName={selectedUserName}
        setUnreadCounts={setUnreadCounts}
      />
    </div>
  );
};

export default App;
