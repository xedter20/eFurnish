import React, { useRef, useEffect, useState } from 'react';
import { Link, useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { Helmet } from "react-helmet";
import toast from "react-hot-toast";
/* images */
import logo from "../../../assets/logo/logo.png";
import signupImg from "../../../assets/images/authentication/signup.jpg";
import useAuth from "../../../hooks/useAuth";
import ReCAPTCHA from 'react-google-recaptcha';

import { Formik, useField, useFormik, Form, Field } from 'formik';
import * as Yup from 'yup';
import InputText from '../../../components/Input/InputText';
import Dropdown from '../../../components/Input/Dropdown';
import {
  regions,
  provinces,
  cities,
  barangays,
  provincesByCode,
  regionByCode
} from 'select-philippines-address';
const Signup = () => {
  // Auth Context for user creation
  const { createUser, updateUserProfile, loading, setLoading } = useAuth();
  // React Hook Form Setup

  const [addressRegions, setRegions] = useState([]);
  const [addressProvince, setProvince] = useState([]);
  const [addressCity, setCity] = useState([]);
  const [addressBarangay, setBarangay] = useState([]);

  const prepareAddress = async () => {
    await regions().then(region => {
      setRegions(
        region.map(r => {
          return {
            value: r.region_code,
            label: r.region_name
          };
        })
      );
    });
    // await regionByCode('01').then(region => console.log(region.region_name));
    await provinces().then(province => console.log(province));
    // await provincesByCode('01').then(province => console.log(province));
    // await provinceByName('Rizal').then(province =>
    //   console.log(province.province_code)
    // );
    await cities().then(city => console.log(city));
    await barangays().then(barangays => console.log(barangays));
  };
  useEffect(() => {
    prepareAddress();
  }, []);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  const navigate = useNavigate();
  const recaptchaRef = useRef();
  // Form Submit handler
  const onSubmit = (data) => {
    const recaptchaValue = recaptchaRef.current.getValue();
    if (!recaptchaValue) {
      alert('Please complete the reCAPTCHA challenge.');
      return;
    }

    // create new user with email and password
    createUser(data.email, data.password)
      .then((result) => {
        const loggedUser = result.user;

        // Update user profile name
        updateUserProfile(data.name)
          .then(() => {
            // Navigate to home page after successful profile update
            setLoading(false);
            toast.success("Account created successfully!");
            navigate("/");
          })
          .catch((error) => {
            // Handle error during profile update
            setLoading(false);
            console.error("Profile update error:", error);
          });
      })
      .catch((error) => {
        // Handle error during user creation
        setLoading(false);
        if (error.message === "Firebase: Error (auth/email-already-in-use).") {
          return toast.error("Email already exists! Please Login!");
        }
        toast.error("Sign-up failed. Please try again later.");
        console.error(error.message);
      });



    reset();
  };



  const formikConfig = {
    initialValues: {
      email: '',
      password: '',
      confirmPassword: '',
      name: '',
      lastName: '',
      address_region: '',
      address_province: '',
      address_city: '',
      address_barangay: '',
      streetAddress: '',
      zipCode: '',
      mobileNumber: ''
    },
    validationSchema: Yup.object({
      email: Yup.string().required('Required field'),
      password: Yup.string()
        .min(8, 'Password must be at least 8 characters')
        .matches(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
          'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'
        )
        .required('Password is required'),
      confirmPassword: Yup.string()
        .oneOf([Yup.ref('password'), null], 'Passwords must match')
        .required('Confirm password is required'),
      name: Yup.string().required('Required field'),
      lastName: Yup.string().required('Required field'),
      address_region: Yup.string().required('Required field'),
      address_province: Yup.string().required('Required field'),
      address_city: Yup.string().required('Required field'),
      address_barangay: Yup.string().required('Required field'),
      streetAddress: Yup.string().required('Required field'),
      zipCode: Yup.string().required('Required field'),
      mobileNumber: Yup.string()
        .matches(/^9\d{9}$/, "Must be a valid PH mobile number (9xxxxxxxxx)")
        .required("Mobile number is required"),

    }),
    onSubmit: async (
      values,
      { setSubmitting, setFieldValue, setErrorMessage, setErrors }
    ) => {

      // console.log({ values })

      // return true;


      let { email, password } = values;

      let { address_region, address_province, address_city, address_barangay, streetAddress } = values;


      let address_region_value = await regionByCode(address_region)
      let address_province_value = await provincesByCode(address_region).then((data) => {
        return data.find(p => p.province_code === address_province)
      })



      let address_cities_value = await cities(address_province).then((data) => {
        return data.find(p => p.city_code === address_city)
      })


      let address_barangay_value = await barangays(address_city).then((data) => {
        return data.find(p => p.brgy_code === address_barangay)
      })





      await createUser(email, password)
        .then((result) => {
          const loggedUser = result.user;

          // Update user profile name
          // updateUserProfile(data.name)
          //   .then(() => {
          //     // Navigate to home page after successful profile update
          //     setLoading(false);
          //     toast.success("Account created successfully!");
          //     navigate("/");
          //   })
          //   .catch((error) => {
          //     // Handle error during profile update
          //     setLoading(false);
          //     console.error("Profile update error:", error);
          //   });
        })
        .catch((error) => {
          // Handle error during user creation
          setLoading(false);
          if (error.message === "Firebase: Error (auth/email-already-in-use).") {
            return toast.error("Email already exists.");
          }
          toast.error("Sign-up failed. Please try again later.");
          console.error(error.message);
        });





    }
  };

  return (
    <section className="mx-auto h-full max-h-[1080px] min-h-screen w-full max-w-[1440px] grid-cols-12 px-[4%] py-10 font-Poppins md:grid md:px-[7%]">
      <Helmet>
        <title>Sign Up - HandiHub Shop</title>
      </Helmet>
      {/* image container */}
      <div className="hidden md:col-span-6 md:block">
        <img
          className="h-full max-h-[671px] w-full rounded-[10px] object-cover object-center"
          src={signupImg}
          alt="elegant sofa chair minimal photo"
          loading="lazy"
        />
      </div>
      {/* form container */}
      <div className="col-span-full md:col-start-8">
        {/* Logo & Title */}
        <Link to="/" className="inline-flex items-center">
          <img className="w-20 h-20" src={logo} alt="urbanAura logo" loading="lazy" />
          {/* <h1 className="ml-1 font-Montserrat text-2xl font-bold md:text-[34px]">
            atan
          </h1> */}
        </Link>
        {/* form */}
        <div className="">
          <Formik {...formikConfig}>
            {({
              handleSubmit,
              handleChange,
              handleBlur, // handler for onBlur event of form elements
              values,
              touched,
              errors,
              setFieldValue,
              isSubmitting
            }) => {
              return <div>
                <h1 className="text-4xl font-semibold mb-2">Register</h1>
                <div className="flex flex-col gap-x-6 gap-y-16 md:flex-row">



                  <Form className="">
                    <div className="z-50 grid grid-cols-1 gap-3 md:grid-cols-2 ">
                      <InputText
                        // icons={mdiAccount}
                        label="First Name"
                        labelColor="text-white"
                        name="name"
                        type="text"
                        placeholder=""
                        value={values.name}
                        onBlur={handleBlur} // This apparently updates `touched`?
                      />
                      <InputText
                        // icons={mdiAccount}
                        label="Last Name"
                        labelColor="text-white"
                        name="lastName"
                        type="text"
                        placeholder=""
                        value={values.lastName}
                        onBlur={handleBlur} // This apparently updates `touched`?
                      />

                    </div>

                    <InputText
                      // icons={mdiAccount}
                      label="Email"
                      labelColor="text-white"
                      name="email"
                      type="text"
                      placeholder=""
                      value={values.email}
                      onBlur={handleBlur} // This apparently updates `touched`?
                    />



                    <div className="z-50 grid grid-cols-1 gap-3 md:grid-cols-2 ">
                      <InputText
                        // icons={mdiAccount}
                        label="Password"
                        labelColor="text-white"
                        name="password"
                        type="text"
                        placeholder=""
                        value={values.password}
                        onBlur={handleBlur} // This apparently updates `touched`?
                      />
                      <InputText
                        // icons={mdiAccount}
                        label="Confirm Password"
                        labelColor="text-white"
                        name="confirmPassword"
                        type="text"
                        placeholder=""
                        value={values.confirmPassword}
                        onBlur={handleBlur} // This apparently updates `touched`?
                      />

                    </div>
                    {/* <InputText
                      // icons={mdiAccount}
                      label="Email"
                      labelColor="text-white"
                      name="email"
                      type="text"
                      placeholder=""
                      value={values.email}
                      onBlur={handleBlur} // This apparently updates `touched`?
                    /> */}
                    <div className="z-50 grid grid-cols-1 gap-3 md:grid-cols-2 ">
                      <Dropdown
                        className="z-50"

                        label="Region"
                        name="address_region"
                        value={values.address_region}
                        setFieldValue={setFieldValue}
                        onBlur={handleBlur}
                        options={addressRegions}
                        affectedInput="address_province"
                        allValues={values}
                        functionToCalled={async regionCode => {
                          if (regionCode) {
                            setFieldValue('address_province', '');
                            await provincesByCode(regionCode).then(
                              province => {
                                setProvince(
                                  province.map(p => {
                                    return {
                                      value: p.province_code,
                                      label: p.province_name
                                    };
                                  })
                                );
                              }
                            );
                          }
                        }}
                      />

                      <Dropdown
                        className="z-50"

                        label="Province"
                        name="address_province"
                        value={values.address_province}
                        d
                        setFieldValue={setFieldValue}
                        onBlur={handleBlur}
                        options={addressProvince}
                        affectedInput="address_city"
                        functionToCalled={async code => {
                          if (code) {
                            await cities(code).then(cities => {
                              setCity(
                                cities.map(p => {
                                  return {
                                    value: p.city_code,
                                    label: p.city_name
                                  };
                                })
                              );
                            });
                          }
                        }}
                      />

                    </div>
                    <div className="z-50 grid grid-cols-1 gap-3 md:grid-cols-2 ">
                      <Dropdown
                        className="z-50"

                        label="City"
                        name="address_city"
                        // value={values.civilStatus}
                        setFieldValue={setFieldValue}
                        onBlur={handleBlur}
                        options={addressCity}
                        affectedInput="address_barangay"
                        functionToCalled={async code => {
                          if (code) {
                            await barangays(code).then(cities => {
                              setBarangay(
                                cities.map(p => {
                                  console.log({ p });
                                  return {
                                    value: p.brgy_code,
                                    label: p.brgy_name
                                  };
                                })
                              );
                            });
                          }
                        }}
                      />
                      <Dropdown
                        className="z-50"

                        label="Barangay"
                        name="address_barangay"
                        value={values.address_barangay}
                        setFieldValue={setFieldValue}
                        onBlur={handleBlur}
                        options={addressBarangay}
                        affectedInput=""
                        functionToCalled={async code => { }}
                      />
                    </div>
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 ">
                      <InputText
                        // icons={mdiAccount}
                        label="Street Address"
                        labelColor="text-white"
                        name="streetAddress"
                        type="text"
                        placeholder=""
                        value={values.streetAddress}
                        onBlur={handleBlur} // This apparently updates `touched`?
                      />
                      <InputText
                        // icons={mdiAccount}
                        label="Zip Code"
                        labelColor="text-white"
                        name="zipCode"
                        type="text"
                        placeholder=""
                        value={values.zipCode}
                        onBlur={handleBlur} // This apparently updates `touched`?
                      />


                    </div>


                    <div className="relative">
                      <label
                        className={`block mb-2 text-neutral-900 text-left `}>
                        Mobile Number</label>
                      <div className="flex items-center border border-gray-300 rounded-md shadow-sm px-3 py-2 max-w-full border-gray-700 rounded w-full dark:placeholder-gray-400">
                        <span className="inline-flex items-center px-3  text-gray-500 text-sm border-r border-gray-300">
                          +63
                        </span>
                        <Field
                          name="mobileNumber"
                          render={({ field }) => (
                            <input
                              {...field}
                              type="text"
                              value={values.mobileNumber}
                              onChange={(e) => {
                                // Limit input to 10 digits (9xxxxxxxxx format)
                                const value = e.target.value.replace(/\D/g, ""); // Remove non-numeric characters
                                if (value.length <= 10) {
                                  setFieldValue("mobileNumber", value);
                                }
                              }}
                              placeholder="9123456789"
                              className="block w-full px-4 py-2 text-white-900 focus:outline-none focus:ring-1 focus:ring-white-500 rounded-r-md"
                            />
                          )}
                        />
                      </div>
                      {touched.mobileNumber && errors.mobileNumber ? (
                        <div className="text-xs text-left text-red-500 dark:text-red-400 mt-1">
                          {errors.mobileNumber}
                        </div>
                      ) : null}
                    </div>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className={
                        'btn mt-4 bg-yellow-500 text-white font-bold'

                      }>
                      Submit
                    </button>
                  </Form>


                </div>
              </div>
            }}
          </Formik>
          {/* <form onSubmit={handleSubmit(onSubmit)}>
            <h1 className="text-4xl font-semibold">Register</h1>
            <p className="text-cadetGray mt-2 text-xl italic">Join Us Today</p>

            <label
              htmlFor="name"
              className="text-cadetGray mb-2 mt-10 block w-full"
            >
              {errors.name ? (
                <span className="text-red-500">Name is required*</span>
              ) : (
                "Name"
              )}
            </label>
            <input
              className="block w-full rounded-[10px] border px-3 py-2 text-lg outline-none focus:border-gray-500"
              type="text"
              id="name"
              {...register("name", { required: true })}
            />
            <label
              htmlFor="email"
              className="text-cadetGray mb-2 mt-6 block w-full"
            >
              {errors.email ? (
                <span className="text-red-500">Email is required*</span>
              ) : (
                "Email"
              )}
            </label>
            <input
              className="block w-full rounded-[10px] border px-3 py-2 text-lg outline-none focus:border-gray-500"
              type="email"
              id="email"
              {...register("email", { required: true })}
            />
            <label
              htmlFor="password"
              className="text-cadetGray mb-2 mt-6 block w-full"
            >
              {errors.password ? (
                <span className="text-sm text-red-500">
                  Password is required
                </span>
              ) : (
                "Password"
              )}
            </label>
            <input
              className="block w-full rounded-[10px] border px-3 py-2 text-lg outline-none focus:border-gray-500"
              type="password"
              id="password"
              {...register("password", {
                required: true,
                // pattern: /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/,
              })}
            />
            <div className="flex justify-center mb-4 mt-4">
              <ReCAPTCHA
                ref={recaptchaRef}

                sitekey={
                  '6LcGF14qAAAAAAYOOPRg8WJe2Dsn1QwyOISdcUin'
                } // Replace with your site key
              />
            </div>
            <p className="text-cadetGray mb-8 mt-6 text-right text-sm">
              Already have account?{" "}
              <Link to="/login" className="text-medium text-primary">
                Login
              </Link>
            </p>

            <button
              disabled={loading}
              type="Submit"
              className={`block w-full rounded-[10px] py-2 text-xl text-white ${loading ? "bg-[#b88f2fc4]" : "bg-primary transition-all hover:bg-[#a07b26]"}`}
            >
              Sign up
            </button>
          </form> */}
        </div>
      </div>
    </section>
  );
};

export default Signup;
