import { Link } from "react-router-dom";
import { BsArrowRight } from "react-icons/bs";
import categoryImg1 from "../../../../assets/images/home/category-1.webp";
import categoryImg2 from "../../../../assets/images/home/category-2.jpg";
import categoryImg3 from "../../../../assets/images/home/category-3.jpg";
import categoryImg4 from "../../../../assets/images/home/category-4.jpg";
const Categories = () => {

  const categories = [
    {
      title: 'Bags',
      image: categoryImg1, // Replace with actual image URL
      link: '/products?category=bags',
    },
    {
      title: 'Baskets',
      image: categoryImg2, // Replace with actual image URL
      link: '/products?category=baskets',
    },
    {
      title: 'Souvenir',
      image: categoryImg3, // Replace with actual image URL
      link: '/products?category=souvenir',
    },
    {
      title: 'Utensils',
      image: categoryImg4, // Replace with actual image URL
      link: '/products?category=utensils',
    },
  ];

  const CategoryCard = ({ image, title, link }) => {
    return (
      <div className="relative mx-auto w-full max-w-xs overflow-hidden rounded-lg shadow-lg">
        <img
          className="h-64 w-full object-cover"
          src={image}
          alt={title}
          loading="lazy"
        />
        <div className="absolute bottom-0 left-0 w-full bg-black/40 p-4 text-white">
          <h3 className="text-2xl font-semibold">{title}</h3>
          <Link
            to={link}
            className="group mt-2 inline-flex items-center gap-1 border-b border-white pb-0.5"
          >
            Shop Now
            <BsArrowRight
              size={20}
              className="transition-transform duration-300 ease-in group-hover:translate-x-1"
            />
          </Link>
        </div>
      </div>
    );
  };
  return (
    <section className="px-[4%] text-[#333] md:px-[10%]">
      <h1 className="mt-14 text-center text-3xl font-bold">Browse The Range</h1>
      <p className="text-center text-lg text-[#666] md:text-xl">
        Discover our top categories for your perfect home makeover.
      </p>
      {/* cards container */}
      <hr className="mt-4 mb-4" />
      <div className="grid grid-cols-1 gap-6 p-4 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((category, index) => (
          <CategoryCard
            key={index}
            image={category.image}
            title={category.title}
            link={category.link}
          />
        ))}
      </div>
    </section>
  );
};

export default Categories;
